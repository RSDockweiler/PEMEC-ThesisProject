function [GCI_fine,phi_mf_ext,s] = GCI_FUNC(phi_coarse,phi_medium,phi_fine,N_coarse,N_medium,N_fine)

r_mf = (N_fine/N_medium)^(1/3); % the mesh refinement factor, medium-fine 
r_cm = (N_medium/N_coarse)^(1/3); % the mesh refinement factor, coarse-medium

epsilon_cm = phi_coarse - phi_medium; % Solution difference, coarse-medium
epsilon_mf = phi_medium - phi_fine; % Solution difference, coarse-medium
s = sign(epsilon_cm./epsilon_mf); % sign, used for p

p = zeros(length(phi_coarse),1); % array for p
phi_mf_ext = zeros(length(phi_coarse),1); % array for extrapolated values
e_mf_a = zeros(length(phi_coarse),1); % approximated error array
%e_mf_ext = zeros(length(phi_coarse),1); % extrapolated error array
GCI_fine = zeros(length(phi_coarse),1); % GCI fine array
counter = zeros(length(phi_coarse),1); % counter for each p iteration
for i = 1: length(phi_coarse) 
q = 0; % Setting q = 0 first iteration
p_old = 1/(log(r_mf))*abs(log(abs(epsilon_cm(i)/epsilon_mf(i)))+q);
error = 1;
while error > 10e-14 % FIXED-POINT ITERATION
    counter(i) = counter(i) +1; % Updating counter
    q = log((r_mf^p_old-s(i))/(r_cm^p_old-s(i))); % Updating q
    % Updating p
    p_new = 1/(log(r_mf))*abs(log(abs(epsilon_cm(i)/epsilon_mf(i)))+q);
    
    error = abs(p_new-p_old); % Updating error
    p_old = p_new; % Updating old p
    
    % Used for debugging, to see how p develops:
    p_develop(i,counter(i)) = p_old;
end
p(i) = p_new; % Saving final p values

% Extrapolating values:
phi_mf_ext(i) = (r_mf^p(i)*phi_fine(i)-phi_medium(i))/(r_mf^p(i) - 1);
% Approximate error:
e_mf_a(i) = abs((phi_fine(i) - phi_medium(i))/phi_fine(i));
%e_mf_ext(i) = abs((phi_mf_ext(i) - phi_fine(i))/phi_fine(i));
% Calculating estimated numerical error of fine grid:
GCI_fine(i) = 1.25*e_mf_a(i)/(r_mf^p(i)-1);
end