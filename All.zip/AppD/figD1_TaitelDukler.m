%% Taitel and Dukler
close all; clear all; clc
%% Data
load("taitel1.mat")
load("taitel2.mat")
load("taitel3.mat")
taitel1 = 10.^(taitel1);
taitel2 = 10.^(taitel2);
taitel3 = 10.^(taitel3);

%% Inputs
l = 50e-3; % Length of channel
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer
A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2
D_hyd = 1e-3;
A_c = 1e-3*1e-3;
T = 353;
p = 1e5;
%%
i_strat = 1;
i_plug = 0.89;
i_slug = 44;
lambda_strat = 350;
lambda_plug = 4398;
lambda_slug = 88;

[stratX,stratFr,stratT,stratK] = taitelAndDuklerFunc(i_strat,lambda_strat,D_hyd,A_c,A_mea_cm,T,p);
[plugX,plugFr,plugT,plugK] = taitelAndDuklerFunc(i_plug,lambda_plug,D_hyd,A_c,A_mea_cm,T,p);
[slugX,slugFr,slugT,slugK] = taitelAndDuklerFunc(i_slug,lambda_slug,D_hyd,A_c,A_mea_cm,T,p);


%% Plots
close all
tiledlayout(3,1)
nexttile
loglog(slugX,slugFr,'o','LineWidth',2.5,'MarkerSize',6)
hold on
loglog(plugX,plugFr,'s','LineWidth',2.5,'MarkerSize',7)
loglog(stratX,stratFr,'+','LineWidth',2,'MarkerSize',8)
loglog(taitel1(:,1),taitel1(:,2),'Color',[0 0.4470 0.7410])
loglog([1.5181 1.5181],[0.1418 4*10],'Color',[0 0.4470 0.7410])

ylim([10^-3 4*10])
xlim([10^(-3) 10^4])
grid on
legend('$i = 44$, $\lambda = 88$','$i = 0.89$, $\lambda = 4398$', ...
    '$i = 1$, $\lambda = 350$','interpreter','latex','FontSize',10)
ylabel('Froude Number, $Fr$ [-]','Interpreter','latex','FontSize',12)
xlabel('Martinelli Parameter, $X$ [-]','Interpreter','latex','FontSize',12)
text(0.01,4,'Annular flow','Interpreter','latex','FontSize',12)
nexttile
loglog(taitel2(1:end,1),taitel2(1:end,2))
hold on
loglog(stratX,stratK,'+','LineWidth',2,'MarkerSize',8,'Color',[0.9290 0.6940 0.1250])
ylim([0 10^2])
xlim([10^(-3) 10^4])
grid on
ylabel('$K$ [-]','Interpreter','latex','FontSize',12)
xlabel('Martinelli Parameter, $X$ [-]','Interpreter','latex','FontSize',12)
text(0.1,20,'Wavy flow','Interpreter','latex','FontSize',12)
text(0.1,3,'Stratified flow','Interpreter','latex','FontSize',12)
nexttile
loglog(taitel3(1:end,1),taitel3(1:end,2))
hold on
loglog(plugX,plugT,'s','LineWidth',2.5,'MarkerSize',7)
ylim([10^(-3) 10])
xlim([10^(-3) 10^4])
ylabel('$T$ [-]','Interpreter','latex','FontSize',12)
xlabel('Martinelli Parameter, $X$ [-]','Interpreter','latex','FontSize',12)
grid on
text(10,2,'Bubbly flow','Interpreter','latex','FontSize',12)
text(1,0.03,'Intermittent (plug/slug) flow','Interpreter','latex','FontSize',12)

findfigs