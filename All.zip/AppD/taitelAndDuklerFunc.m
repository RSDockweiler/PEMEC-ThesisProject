function [X,Fr,T,K] = taitelAndDuklerFunc(i,lambda,D_hyd,A_c,A_mea_cm,T,p)
%% Constants
g = 9.81;
F = 96485;
M_H2O = 18e-3;
M_O2 = 32e-3;
rho_l = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Water');
rho_g = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Oxygen');
mu_l = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Water');
mu_g = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Oxygen');
nu_l = mu_l/rho_l;
nu_g = mu_g/rho_g;
%% Calculations
n_dot_o2_out = i*A_mea_cm/(4*F); % Molar flow of oxygen out
m_dot_o2_out = n_dot_o2_out*M_O2; % Mass flow of oxygen out
G_o2 = m_dot_o2_out/A_c; % Mass flux of oxygen
V_gs = G_o2/rho_g; % Superficial velocity of oxygen

n_dot_h2o_out = i*A_mea_cm*lambda/(2*F); % Molar flow of water out
m_dot_h2o_out = n_dot_h2o_out*M_H2O; % Mass flow of water out
G_h2o = m_dot_h2o_out/A_c; % Mass flux of water
V_ls = G_h2o/rho_l; % Superficial velocity of water
G_total = G_h2o + G_o2; % Total mass flux
x = G_o2/G_h2o; % Quality
alpha = V_gs/(V_ls+V_gs); % Void fraction

% Actual velocity of each phase
u_o2 = V_gs/alpha;
u_h2o = V_ls/(1-alpha);

% Reynolds number
Re_g = V_gs*D_hyd/nu_g;
Re_l = V_ls*D_hyd/nu_l;

% Determining m, n, cg and cl depending on turbulent or laminar flow
if Re_g > 2300
    cg = 0.046;
    m = 0.2;
else
    cg = 16;
    m = 1;
end
if Re_l > 2300
    cl = 0.046;
    n = 0.2;
else
    cl = 16;
    n = 1;
end
% Liquid and gas pressure gradient
dpdz_l = (4*cl/D_hyd)*(V_ls*D_hyd/nu_l)^(-n)*(rho_l*V_ls^2/2);
dpdz_g = (4*cg/D_hyd)*(V_gs*D_hyd/nu_g)^(-m)*(rho_g*V_gs^2/2);
X = sqrt(dpdz_l/dpdz_g); % Martinelli parameter
Fr = G_o2/sqrt((rho_g*(rho_l-rho_g)*D_hyd*g)); % Froude
T = sqrt(abs(dpdz_l)/(g*(rho_l-rho_g))); % T
K = Fr*sqrt(G_h2o*D_hyd/mu_l); % K
end