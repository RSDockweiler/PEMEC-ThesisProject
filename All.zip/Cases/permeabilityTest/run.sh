#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
#------------------------------------------------------------------------------

Method=("0.5" "0.6" "0.7" "0.8" "1.0" "1.1" "1.2" "1.3" "1.4" "1.5" "1.6" "1.7" "1.8" "1.9" "10")
len_i=${#Method[@]} # loop length lol
K=("1e6" "1e7" "1e8" "2.25e8" "5e8" "7.75e8" "1e9" "2.25e9" "5e9" "7.75e9" "1e10" "2.25e10" "5e10" "7.5e10" "1e11")

cd K11
#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions

blockMesh
mapFields -consistent -sourceTime 'latestTime' ../../Grid/grid3
rm 0/*Mean
setFields
decomposePar

for (( i=0; i<$len_i; i++ )); do
    d3="${Method[i]}"
    d2="${K[i]}"
    rm log*

    sed -i "25s/.*/endTime $d3;/" ./system/controlDict # Updating end time
    sed -i "17s/.*/invK $d2;/" ./constant/porousProperties # PERMEABILITY

    runParallel $(getApplication)
done

reconstructPar -latestTime

