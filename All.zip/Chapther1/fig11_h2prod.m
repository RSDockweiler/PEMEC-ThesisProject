clear all; close all;
load("H2Prod.mat")
fontLeg = 20;
fontXY = 20;
fontGCA = 14;
x = [1975,1980,1985,1990,1995,2000,2005,2010,2015,2018];
y = reshape(Data001(:,2),[10,3]);
i = 0;
y = zeros(10,3);
j = 1;
for i = 1:10
    y(i,1:3)=Data001(j:j+2,2)';
    j=j+3;
end
yOG = y;

for i = 1:length(y)
    y(i,3) = y(i,3)-y(i,2);
    y(i,2) = y(i,2)-y(i,1);
end
y(9,3) = yOG(9,1)-yOG(9,2);
y(9,2) = yOG(9,2)-yOG(9,3);
y(9,1) = yOG(9,3);
%y = [2 2 3; 2 5 6; 2 8 9; 2 11 12];
X = categorical({'1975','1980','1985','1990','1995','2000','2005','2010','2015','2018'});
X = reordercats(X,{'1975','1980','1985','1990','1995','2000','2005','2010','2015','2018'});
tiledlayout(1,2)
figure('units','normalized','outerposition',[0.1 0.1 0.75 0.75])
nexttile
bar(X,y,'stacked')
grid on
ax = gca;
ax.FontSize = fontGCA;
legend('Refining','Ammonia','Other pure','Interpreter','latex','FontSize',fontLeg)
xlabel('Year','Interpreter','latex','FontSize',fontXY)
ylabel('Annual Hydrogen Production [Mt/yr]','Interpreter','latex','FontSize',fontXY)

coal = 23;
ng = 76;
elec = 100 - coal - ng;
% X = [coal,ng,elec];
labels = {'Coal, 23 \%','Natural gas, 76 \%','Electrolysis, 1 \%'};


nexttile
ax = gca(); 
ax.FontSize = 100;
pieData = [coal,ng,elec]; 
h = pie(ax, pieData); 
% Define 3 colors, one for each of the 3 wedges
newColors = [0 0.4470 0.7410;0.8500 0.3250 0.0980;0.9290 0.6940 0.1250];

% h=pie() output is a vector of alternating patch and text handles. 
% Isolate the patch handles
patchHand = findobj(h, 'Type', 'Patch'); 
% Set the color of all patches using the nx3 newColors matrix
set(patchHand, {'FaceColor'}, mat2cell(newColors, ones(size(newColors,1),1), 3))
% Or set the color of a single wedge
legend(labels,'Interpreter','latex','FontSize',fontLeg)

