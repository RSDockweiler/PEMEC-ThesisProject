
%% Flow
l = 50e-3; % Length of channel 
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer

A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2

T = 353;
pres = 101325;
M_H2O = 18e-3; % kg/mol
M_O2 = 32e-3; % kg/mol
lambda = 350; % Stoichometric flow ratio 
j = 1; % A/cm^2, current density
F =  9.6485e4; % Faradays, C/mol
m_dot_in = M_H2O*lambda*j*A_mea_cm/(2*F); % Mass flow in, H2O
m_dot_O2 = M_O2*j*A_mea_cm/(4*F); % O2 generation
m_dot_H2O = -M_H2O*j*A_mea_cm/(2*F); % H2O flux out
rho = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',pres,'Water'); % rho water
rho_air = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',pres,'Oxygen'); % rho o2
mu_water = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',pres,'Water');
mu_o2 = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',pres,'Oxygen');
nu=mu_water/rho; % Kinematic viscosity, H2O


p = 2*h_ch+2*w_ch; % wetted perimeter
A_c = w_ch*h_ch; % cross area
D_h = 4*A_c/p; % hydraulic diameter
u_air = m_dot_O2/(A_mea*rho_air) % velocity o2, in
u_H2O = m_dot_H2O/(A_mea*1000) % velocity water, out
u = m_dot_in/(A_c*rho) % velocity water, in
Re = u*D_h/nu % Re, in
%%
close all;
matSize = 100;
x = linspace(0,1e-3,matSize);
y = linspace(0,1e-3,matSize);
x_c = 0.5e-3;
y_c = 0.5e-3;
[X,Y] = meshgrid(x,y);
Z = zeros(matSize,matSize);
for i = 1:matSize
    for j = 1:matSize
        Z(i,j) = u*(1-((Y(i,j)-y_c)/y_c)^4)*(1-((X(i,j)-x_c)/x_c)^4);
    end
end
ratio = u/mean(Z,'All');

%%
close all;
AXFont = 12;
YFont = 16;
XFont = 16;
CBFont = 20;
TitFont = 16;


f=figure;
ax=nexttile;
contourf(X,Y,Z*ratio,10);
ax.DataAspectRatio=[1 1 .5];
%colorbar('TickLabels','very long tick labels');

%contourf(X,Y,Z*ratio,10)
ax = gca; % current axes
ax.FontSize = AXFont;
ylabel('y postion','Interpreter','latex','FontSize',YFont)
xlabel('x postion','Interpreter','latex','FontSize',XFont)
cb = colorbar;
%cb.Layout.Tile = 'east';
%ylabel(cb, '$u_{in,z}(x,y)$ [m/s]','Interpreter','latex','FontSize',CBFont)
xticks([0 0.5e-3 1e-3])
xticklabels({'0','Center','1','Interpreter','latex'})
yticks([0 0.5e-3 1e-3])
yticklabels({'0','Center','1','Interpreter','latex'})
set(cb,'XTick',[0 u 1.447*u])
set(cb,'XTickLabel',{'0','u_{in,avg}','1.6u_{in,avg}','Interpreter','latex','FontSize',CBFont})
cb.FontSize = 12;
ylabel(cb, '$u_{in,z}(x,y)$ [m/s]','Interpreter','latex','FontSize',CBFont)