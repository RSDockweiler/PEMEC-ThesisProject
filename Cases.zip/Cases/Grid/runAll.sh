#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
#------------------------------------------------------------------------------

cd grid1-noP

cp -r 0.orig 0/
sed -i "17s/.*/numberOfSubdomains 32;/" ./system/decomposeParDict # DECOMPOSE
sed -i "49s/.*/maxCo   	 0.9;/" ./system/controlDict # COURANT NUMBER
sed -i "19s/.*/startFrom       latestTime;/" ./system/controlDict # INITIAL START TIME
sed -i "21s/.*/startTime 0;/" ./system/controlDict # INITIAL START TIME
sed -i "25s/.*/endTime 1;/" ./system/controlDict # INITIAL END TIME
#blockMesh
#decomposePar
#runParallel $(getApplication)

cd ..
#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
#------------------------------------------------------------------------------
Method=("grid2-noP" "grid3-noP" "grid4-noP")
Method2=("grid1-noP" "grid2-noP" "grid3-noP")
Method3=("grid1" "grid2" "grid3" "grid4")
Method4=("grid4-noP" "grid1" "grid2" "grid3")
len_i=${#Method[@]} # loop length lol
for (( i=0; i<$len_i; i++ )); do
    d="${Method[i]}"
    d2="${Method2[i]}"
    cd $d
    #!/bin/sh
    cd "${0%/*}" || exit                                # Run from this directory
    . ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
    #------------------------------------------------------------------------------
    sed -i "17s/.*/numberOfSubdomains 2;/" ./system/decomposeParDict # DECOMPOSE
    sed -i "49s/.*/maxCo   	 0.9;/" ./system/controlDict # COURANT NUMBER
    sed -i "19s/.*/startFrom       latestTime;/" ./system/controlDict # INITIAL START TIME
    sed -i "21s/.*/startTime 0;/" ./system/controlDict # INITIAL START TIME
    sed -i "25s/.*/endTime 1;/" ./system/controlDict # INITIAL END TIME
    sed -i "31s/.*/writeInterval   1;/" ./system/controlDict # INITIAL END TIME
    #blockMesh
    #mapFields -consistent -sourceTime 'latestTime' ../$d2
    #decomposePar
    #runParallel $(getApplication)
    cd ..
done

for (( i=0; i<$len_i; i++ )); do
    d3="${Method3[i]}"
    d4="${Method4[i]}"
    cd $d3
    #!/bin/sh
    cd "${0%/*}" || exit                                # Run from this directory
    . ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
    #------------------------------------------------------------------------------
    sed -i "17s/.*/numberOfSubdomains 2;/" ./system/decomposeParDict # DECOMPOSE
    sed -i "49s/.*/maxCo   	 0.9;/" ./system/controlDict # COURANT NUMBER
    sed -i "19s/.*/startFrom       latestTime;/" ./system/controlDict # INITIAL START TIME
    sed -i "21s/.*/startTime 0;/" ./system/controlDict # INITIAL START TIME
    sed -i "25s/.*/endTime 8;/" ./system/controlDict # INITIAL END TIME
    sed -i "31s/.*/writeInterval   1;/" ./system/controlDict # INITIAL END TIME
    #blockMesh
    #mapFields -consistent -sourceTime 'latestTime' ../$d4
    #setFields
    #decomposePar
    #runParallel $(getApplication)
    cd ..
done
