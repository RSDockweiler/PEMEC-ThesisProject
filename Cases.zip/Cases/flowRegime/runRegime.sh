#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
#------------------------------------------------------------------------------

cd plug
#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
rm log*
    mapFields -consistent -sourceTime 'latestTime' ../../Grid/grid3
    rm 0/*Mean
    rm 0/U.o2
    rm 0/U.water
    cp U.waterPlug3  0/U.water
    cp U.o2Plug      0/U.o2
    runApplication blockMesh
    runApplication setFields
    runApplication decomposePar -latestTime
    runParallel $(getApplication)
    reconstructPar -latestTime
cd ..
#------------------------------------------------------------------------------

cd slug
#!/bin/sh
cd "${0%/*}" || exit                                # Run from this directory
. ${WM_PROJECT_DIR:?}/bin/tools/RunFunctions        # Tutorial run functions
    mapFields -consistent -sourceTime 'latestTime' ../plug
    rm 0/*Mean
    rm 0/U.o2
    rm 0/U.water
    cp U.waterSlug3  0/U.water
    cp U.o2Slug      0/U.o2
    runApplication blockMesh
    runApplication setFields
    runApplication decomposePar -latestTime
    runParallel $(getApplication)
    reconstructPar -latestTime
cd ..
#------------------------------------------------------------------------------
