%% Global Dimensionless Numbers
close all; clc; clear all;
%% Constants
l = 50e-3; % Length of channel
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer

A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2

M_H2O = 18e-3; % kg/mol
M_O2 = 32e-3; % kg/mol
lambda = 350; % Stoichometric flow ratio
j = 1; % A/cm^2, current density
F =  9.6485e4; % Faradays, C/mol
T = 353;
p = 101325;

rho_c = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Water');
rho_p = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Oxygen');
mu_c = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Water');
mu_d = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Oxygen');



m_dot_in = M_H2O*lambda*j*A_mea_cm/(2*F); % Mass flow in, H2O
m_dot_O2 = M_O2*j*A_mea_cm/(4*F); % O2 generation
m_dot_H2O = -M_H2O*j*A_mea_cm/(2*F); % H2O flux out

p = 2*h_ch+2*w_ch; %
A_c = w_ch*h_ch;
D_hyd = 4*A_c/p;

u = m_dot_in/(A_c*rho_c); % velocity, inlet

d_p = 1e-6:1e-6:100e-6; % particle diameter

k_B = 1.380649*10^(-23); % boltzmann constant
%% Calculations
for i = 1:length(d_p)
    D_b(i) = k_B*T/(3*pi*mu_c*d_p(i)); % Brownian diffusion coeff estimate
    epsilon(i) = d_p(i)/D_hyd; % Dim. less particle size
    St(i) = rho_p*d_p(i)^2*u/(18*mu_c*D_hyd); % Stokes number
    Pe_f(i) = u*D_hyd/D_b(i); % Peclet flow number associated with Brownian motion
    Re(i) = u*D_hyd*rho_c/mu_c; % Reynolds number

    Brown(i) = 1/((epsilon(i)*St(i)*Pe_f(i))^(1/2)); % Relative importance of brown
    History(i) = (epsilon(i)*Re(i)*St(i))^(1/2); % Relative importance of history force
end
%% Plots
close all;
semilogy(d_p,epsilon,'-*','MarkerIndices',1:10:length(d_p))
hold on
semilogy(d_p,St,'-+','MarkerIndices',1:10:length(d_p))
semilogy(d_p,Pe_f,'-x','MarkerIndices',1:10:length(d_p))
semilogy(d_p,Re,'-','MarkerIndices',1:10:length(d_p))
semilogy(d_p,Brown,'-s','MarkerIndices',1:10:length(d_p))
semilogy(d_p,History,'-o','MarkerIndices',1:10:length(d_p))
semilogy([50e-6;50e-6],[1e-10;1e10],'--')
semilogy(50e-6,Brown(50),'s','MarkerFaceColor',[0.4660 0.6740 0.1880],'MarkerSize',10,'MarkerEdgeColor',[0.4660 0.6740 0.1880])
semilogy(50e-6,History(50),'o','MarkerFaceColor',[0.3010 0.7450 0.9330],'MarkerSize',9,'MarkerEdgeColor',[0.3010 0.7450 0.9330])
annotation('textbox', [0.5, 0.2, 0.1, 0.1], 'String', "$1/(\epsilon St Pe_f)^{1/2}=0.023$",'Interpreter','latex')
annotation('textbox', [0.5, 0.2, 0.1, 0.1], 'String', "$(\epsilon ReSt)^{1/2}=0.012$",'Interpreter','latex')
grid on
xlabel('Particle diameter, $d_p$ [$\mu$m]','Interpreter','latex')
ylabel('Dimensionless Number [-]','Interpreter','latex')
xticks(10e-6:10e-6:100e-6)
%yticks([1e-10 1e-5 1e-2 1e-0 1e2 1e5])
xticklabels({'10','20','30','40','50','60','70','80','90','100'})
legend('$\epsilon$','St','$Pe_f$','Re','$1/(\epsilon St Pe_f)^{1/2}$','$(\epsilon ReSt)^{1/2}$','Interpreter','latex')