%% FLow MAP
clear all; close all; clc;
%% Inputs
T = 273+80;
p = 101325;

mu_water = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Water');
mu_o2 = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Oxygen');

%%
M = log10(mu_o2/mu_water);
load('phaseDiagram.mat')
phaseDiagram(9:end,:) = [phaseDiagram(11,:); phaseDiagram(12,:); 
   phaseDiagram(10,:); phaseDiagram(9,:)];
phaseDiagram(1,1) = phaseDiagram(4,1);
phaseDiagram(2,1) = phaseDiagram(3,1);
phaseDiagram(9,1) = phaseDiagram(12,1);
phaseDiagram(10,1) = phaseDiagram(11,1);

figure(5)
hold on
xline(0)
yline(0)
fill(phaseDiagram(1:4,1),phaseDiagram(1:4,2),[0 0.4470 0.7410])
fill(phaseDiagram(5:8,1),phaseDiagram(5:8,2),[0.8500 0.3250 0.0980])
fill(phaseDiagram(9:end,1),phaseDiagram(9:end,2),[0.9290 0.6940 0.1250])
plot([M;M],[-6.9;0],'--+','LineWidth',2)
grid on
ylabel('Capillary Number, log$10(Ca)$ [-]','Interpreter','latex','FontSize',14)
xlabel('Viscosity Ratio, log$10(M)$ [-]','Interpreter','latex','FontSize',14)
text(-7,2,'Viscous fingering','Interpreter','latex','FontSize',14)
text(1,4,'Stable displacement','Interpreter','latex','FontSize',14)
text(0,-7,'Capillary fingering','Interpreter','latex','FontSize',14)

%% 
