%% Steady state
close all; clear all; clc;

%% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 4);

% Specify range and delimiter
opts.DataLines = [6, Inf];
opts.Delimiter = "\t";

% Specify column names and types
opts.VariableNames = ["Time", "areaAveragealphao2", "areaAveragemagUo2", "areaAveragemagUwater"];
opts.VariableTypes = ["double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Import the data
surfaceFieldValue = readtable("surfaceFieldValue.dat", opts);

%% Convert to output type
surfaceFieldValue = table2array(surfaceFieldValue);

%% Clear temporary variables
clear opts

%% Calculations
meanAlpha = mean(surfaceFieldValue(:,2));
meanuo2 = mean(surfaceFieldValue(:,3));
meanuh2o = mean(surfaceFieldValue(:,4));

% Normalizing
normAlpha = surfaceFieldValue(:,2)./meanAlpha;
normuo2 = surfaceFieldValue(:,3)./meanuo2;
normuh2o = surfaceFieldValue(:,4)./meanuh2o;
%% Plots
close all;
figure(1)
plot(surfaceFieldValue(:,1),normAlpha,'-')
hold on
plot(surfaceFieldValue(:,1),normuo2,'--')
plot(surfaceFieldValue(:,1),normuh2o,'-.')
grid on
ylabel('Normalised variable, $\overline{\phi}/\langle\overline{\phi}\rangle$ [-]','Interpreter','latex','FontSize',16)
xlabel('Time, $t$ [s]','Interpreter','latex','FontSize',14)
legend('$\overline{\alpha}_{o2}/\langle\overline{\alpha}_{o2}\rangle$', ...
    '$\overline{u}_{O2}/\langle\overline{u}_{O2}\rangle$' ...
    ,'$\overline{u}_{H2O}/\langle\overline{u}_{H2O}\rangle$','Interpreter','latex','FontSize',14)
