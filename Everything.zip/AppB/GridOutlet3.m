%% GCI Test Setup
clear all; %close all; clc

%% 0.06 slices
% alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
% 6.34395e-07,4.18722e-08,9.1935e-08,0.100027,1.47447e-07,1.0922e-07
% alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
% 6.16599e-07,4.33262e-08,9.65156e-08,0.100027,1.56439e-07,1.09076e-07
% alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
% 5.8868e-07,4.79858e-08,9.65478e-08,0.100028,1.60597e-07,1.13932e-07
% alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
% 5.78114e-07,4.9428e-08,9.81962e-08,0.100029,1.65221e-07,1.15713e-07


A = 1e-6;
%alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
%5.38837e-07,4.23899e-08,9.84516e-08,0.1,1.47479e-07,1.22682e-07
alpha_1 = 5.38837e-07/A;
alphaUH2O_1 = 4.23899e-08/A;
alphaUO2_1 = 9.84516e-08/A;
pMean_1 = 0.100028/A;
UO2_1 = 1.47479e-07/A;
UH2O_1 = 1.22682e-07/A;

%alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
%5.50107e-07,4.26497e-08,1.05344e-07,0.1,1.53881e-07,1.31802e-07
alpha_2 = 5.50107e-07/A;
alphaUH2O_2 = 4.13787e-08/A;
alphaUO2_2 = 1.05344e-07/A;
pMean_2 = 0.100026/A;
UO2_2 = 1.53881e-07/A;
UH2O_2 = 1.31802e-07/A;

%alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
%5.48636e-07,4.5137e-08,1.06532e-07,0.1,1.5703e-07,1.3997e-07
alpha_3 = 5.48636e-07/A;
alphaUH2O_3 = 4.5137e-08/A;
alphaUO2_3 = 1.06532e-07/A;
pMean_3 = 0.100026/A;
UO2_3 = 1.5703e-07/A;
UH2O_3 = 1.3997e-07/A;



%alpha.o2Mean,auH2O_Magnitude,auO2_Magnitude,pMean,U.o2Mean_Magnitude,U.waterMean_Magnitude
%5.5508e-07,4.58033e-08,1.07697e-07,0.1,1.58576e-07,1.44711e-07
alpha_4 = 5.5508e-07/A;
alphaUH2O_4 = 4.58033e-08/A;
alphaUO2_4 = 1.07697e-07/A;
pMean_4 = 0.100029/A;
UO2_4 = 1.58576e-07/A;
UH2O_4 = 1.44711e-07/A;


alpha = [alpha_1 alpha_2 alpha_3 alpha_4];
alphaUO2 = [alphaUO2_1 alphaUO2_2 alphaUO2_3 alphaUO2_4];
alphaUH2O = [alphaUH2O_1 alphaUH2O_2 alphaUH2O_3 alphaUH2O_4];
uO2 = [UO2_1 UO2_2 UO2_3 UO2_4];
uH2O = [UH2O_1 UH2O_2 UH2O_3 UH2O_4];
p = [pMean_1 pMean_2 pMean_3 pMean_4];

n = [49 110 208 360];

[GCI_alpha,phi_mf_alpha,s] = GCI_FUNC(alpha(1),alpha(2),alpha(3),n(1),n(2),n(3));
[GCI_UH2O,phi_mf_UH2O,s] = GCI_FUNC(uH2O(1),uH2O(2),uH2O(3),n(1),n(2),n(3));
[GCI_UO2,phi_mf_UO2,s] = GCI_FUNC(uO2(1),uO2(2),uO2(3),n(1),n(2),n(3));
[GCI_p,phi_mf_p,s] = GCI_FUNC(p(1),p(2),p(3),n(1),n(2),n(3));
[GCI_auO2,phi_mf_auO2,s] = GCI_FUNC(alphaUO2(1),alphaUO2(2),alphaUO2(3),n(1),n(2),n(3));
[GCI_auH2O,phi_mf_auH2O,s] = GCI_FUNC(alphaUH2O(1),alphaUH2O(2),alphaUH2O(3),n(1),n(2),n(3));

[GCI_alpha4,phi_mf_alpha4,s] = GCI_FUNC(alpha(2),alpha(3),alpha(4),n(2),n(3),n(4));
[GCI_UH2O4,phi_mf_UH2O4,s] = GCI_FUNC(uH2O(2),uH2O(3),uH2O(4),n(2),n(3),n(4));
[GCI_UO24,phi_mf_UO24,s] = GCI_FUNC(uO2(2),uO2(3),uO2(4),n(2),n(3),n(4));
[GCI_p4,phi_mf_p4,s] = GCI_FUNC(p(2),p(3),p(4),n(2),n(3),n(4));
[GCI_auO24,phi_mf_auO24,s] = GCI_FUNC(alphaUO2(2),alphaUO2(3),alphaUO2(4),n(2),n(3),n(4));
[GCI_auH2O4,phi_mf_auH2O4,s] = GCI_FUNC(alphaUH2O(2),alphaUH2O(3),alphaUH2O(4),n(2),n(3),n(4));


%%
AXFont = 12+4;
YFont = 16+6;
XFont = 16+6;
CBFont = 16+4;
TitFont = 18+4;
LegFont = 16+2;


nexttile(2)
plot(n(1:3),alphaUH2O(1:3),'-x','LineWidth',2,'MarkerSize',10)
hold on
plot([0 n(4)],[phi_mf_auH2O phi_mf_auH2O],'-.')
plot([0 n(4)],[alphaUH2O(3)*(1-GCI_auH2O) alphaUH2O(3)*(1-GCI_auH2O)],'k--')
%plot([0 n(4)],[alphaUH2O(4)*(1-GCI_auH2O4) alphaUH2O(4)*(1-GCI_auH2O4)],'r-.')
%plot([0 n(4)],[alphaUH2O(4)*(1+GCI_auH2O4) alphaUH2O(4)*(1+GCI_auH2O4)],'r-.')
plot([0 n(4)],[alphaUH2O(3)*(1+GCI_auH2O) alphaUH2O(3)*(1+GCI_auH2O)],'k--')
grid on
ax = gca; % current axes
ax.FontSize = AXFont;
%legend('','Estimated Error Bands, Mesh 3', ...
%    'interpreter','latex','FontSize',LegFont,'Location','Best')
ylabel('$\langle\overline{\dot{V}}_{H2O}\rangle/A$ [m/s]','interpreter','latex','FontSize',YFont)
xlabel('Number of cells in thousands [-]','interpreter','latex','FontSize',XFont)

xlim([0 250])
ylim([0.04 0.06])
title('Outlet of Domain','Interpreter','latex','FontSize',XFont+2)

nexttile(4)
plot(n(1:3),alphaUO2(1:3),'-x','LineWidth',2,'MarkerSize',10)
hold on
plot([0 n(4)],[phi_mf_auO2 phi_mf_auO2],'-.')
plot([0 n(4)],[alphaUO2(3)*(1-GCI_auO2) alphaUO2(3)*(1-GCI_auO2)],'k--')
%plot([0 n(4)],[alphaUO2(4)*(1-GCI_auO24) alphaUO2(4)*(1-GCI_auO24)],'r-.')
%plot([0 n(4)],[alphaUO2(4)*(1+GCI_auO24) alphaUO2(4)*(1+GCI_auO24)],'r-.')
plot([0 n(4)],[alphaUO2(3)*(1+GCI_auO2) alphaUO2(3)*(1+GCI_auO2)],'k--')
grid on
ax = gca; % current axes
ax.FontSize = AXFont;
%legend('','Estimated Error Bands, Mesh 3', ...
%    'interpreter','latex','FontSize',LegFont,'Location','Best')
ylabel('$\langle\overline{\dot{V}}_{O2}\rangle/A$ [m/s]','interpreter','latex','FontSize',YFont)
xlabel('Number of cells in thousands [-]','interpreter','latex','FontSize',XFont)
ylim([0.09 0.11])
xlim([0 250])

nexttile(6)
plot(n(1:3),alpha(1:3),'-x','LineWidth',2,'MarkerSize',10)
hold on
plot([0 n(4)],[phi_mf_alpha phi_mf_alpha],'-.')
plot([0 n(4)],[alpha(3)*(1-GCI_alpha) alpha(3)*(1-GCI_alpha)],'k--')
%plot([0 n(4)],[alpha(4)*(1-GCI_alpha4) alpha(4)*(1-GCI_alpha4)],'r-.')
%plot([0 n(4)],[alpha(4)*(1+GCI_alpha4) alpha(4)*(1+GCI_alpha4)],'r-.')
plot([0 n(4)],[alpha(3)*(1+GCI_alpha) alpha(3)*(1+GCI_alpha)],'k--')
grid on
ax = gca; % current axes
ax.FontSize = AXFont;
%legend('','Estimated Error Bands, Mesh 3', ...
%    'interpreter','latex','FontSize',LegFont,'Location','Best')
ylabel('$\langle\overline{\alpha}_{O2}\rangle$ [-]','interpreter','latex','FontSize',YFont)
xlabel('Number of cells in thousands [-]','interpreter','latex','FontSize',XFont)
ylim([0.5 0.7])
xlim([0 250])


% nexttile
% plot(n,p,'-x','LineWidth',2,'MarkerSize',10)
% hold on
% plot([0 n(4)],[p(3)*(1-GCI_p) p(3)*(1-GCI_p)],'k--')
% plot([0 n(4)],[p(4)*(1-GCI_p4) p(4)*(1-GCI_p4)],'r-.')
% plot([0 n(4)],[p(4)*(1+GCI_p4) p(4)*(1+GCI_p4)],'r-.')
% plot([0 n(4)],[p(3)*(1+GCI_p) p(3)*(1+GCI_p)],'k--')
% grid on
% ax = gca; % current axes
% ax.FontSize = AXFont;
% legend('','Estimated Error Bands, Mesh 3','Estimated Error Bands, Mesh 4', ...
%     'interpreter','latex','FontSize',LegFont)
% ylabel('$\langle\overline{p}$ [Pa]','interpreter','latex','FontSize',YFont)
% xlabel('Number of cells in thousands [-]','interpreter','latex','FontSize',XFont)
% ylim([1e5 1.001e5])

