%% Pol curve
fontLeg = 21;
fontXY = 22;
fontGCA = 16;

%close all;
R = 8.314; % Gas constant
F = 9.648533212*10^4; % Faraday
n = 2; % Number of electrons
p = 30e5; % Op pressure
T = 273+100; % Mean temp, assumed overall
alpha_an = 2; % Charge transfer coeff
alpha_cat = 0.5; % Charge transfer coeff
i0_an = 1e-7; % Table 6, Carmo 2013
i0_cat = 1e-3; % Exchange current density
ASR = (1.575-1.5);
E0 = 1.229-0.9*10^(-3)*(T-298); 
E = E0 + R*T/(n*F) * log(sqrt(0.21/1))
i = 0.01:0.01:5;
k = 5./(5-i);
E_Array = ones(length(i),1)*E;
V = zeros(length(i),1);
V_act = zeros(length(i),1);
V_trans = zeros(length(i),1);
V_ohm = zeros(length(i),1);
j = 1;
while j < length(i)+1;
V_act_an = R*T/(alpha_an*F) * asinh(i(j)/i0_an);
V_act_cat = R*T/(alpha_cat*F) * asinh(i(j)/i0_cat);
V_act(j) = V_act_an + V_act_cat;
V_trans(j) = R*T/(n*F) * log(k(j));
V_ohm(j) = ASR*i(j);
V(j) = E + V_act(j) + V_ohm(j) + V_trans(j);
j=j+1;
end
figure('units','normalized','outerposition',[0.1 0.1 0.75 0.75])
plot(i,V,'-','LineWidth',3)
ax = gca;
ax.FontSize = fontGCA;
hold on
plot(i,E+V_act,'--o','MarkerIndices', 1:40:length(i),'LineWidth',2,'MarkerSize',10)
plot(i,E+V_trans,'--s','MarkerIndices', 1:40:length(i),'LineWidth',2,'MarkerSize',10)
plot(i,E+V_ohm,'--x','MarkerIndices', 1:40:length(i),'LineWidth',2,'MarkerSize',11)
plot(i,E_Array,'--*','MarkerIndices', 1:40:length(i),'LineWidth',2,'MarkerSize',12)
legend('Cell Voltage','Activation losses','Mass transfer losses', ...
    'Ohmic losses','Reversible cell voltage','Interpreter', ...
    'latex','FontSize',fontLeg,'Location','northeastoutside')
grid on
ylim([1 2.5])
ylabel('Voltage, $V$ [V]','Interpreter','latex','FontSize',fontXY)
xlabel('Current density, $i$ [A/cm$^2$]','Interpreter','latex','FontSize',fontXY)