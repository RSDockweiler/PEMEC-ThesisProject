%% Porous Script
close all; clc; clear all;
fontLeg = 20;
fontXY = 20;
fontGCA = 14;

%% Constants for the model
m = 0.6489;
n = 2.848;
p_cb = 8200;
s_irr = 0.1;
%% Effective saturation
method = 1; % Method 1, 2, 3 or 4 (Method 1 used in model)
s = [0:0.001:0.999];
s_e = zeros(1,length(s));
if method == 1
    for i = 1:length(s)
            s_e(i) = (s(i)-s_irr)./(1-s_irr);
    end
        s_e(s_e<0.1) = 0.1;
elseif method == 2
    s_r = s.*(1-0.2);
    s_e = (s-s_r)./(1-s_r);
elseif method == 3
    s_e = (s-0.1)./(1-0.1);
else
    f_hi = 0.35;
for i = 1:length(s)
    if s(i)>f_hi
        s_e(i) = (s(i)-f_hi)/(1-f_hi);
    else
        s_e(i) = (f_hi-s(i))/f_hi;
    end
end
end

%% Relative permeability
k_rell = s_e.^(1/2) .* (1-(1-s_e.^(1/m)).^(m)).^(1/2);
k_relg = (1-s_e).^(1/3).*(1-s_e.^(1/m)).^(2*m);

%% Capillary pressure
p_c = zeros(length(s_e),1);
for i = 1:length(s_e)
    p_c(i)=p_cb*(s_e(i)^(-1/m)-1)^(1/n);
end

%% F_Darcy/U
mu1 = 0.02065e-3; % Pa/s, oxygen
mu2 = 0.000853; % Pa/s, water
vareps = 0.82; % Porosity
invK = 2.25e11;
F_D1 = invK*vareps.*(1-s).*mu1./k_relg;
F_D2 = invK*vareps.*s.*mu2./k_rell;


%% Figures
figure('units','normalized','outerposition',[0.1 0.1 0.75 0.75])
tiledlayout(2,2)
nexttile
hold on
plot(s_e,k_rell,'--','LineWidth',2)
plot(s_e,k_relg,'LineWidth',2)
ax = gca;
ax.FontSize = fontGCA;
xlabel('Effective Saturation, $s_e$ [-]','interpreter','latex','FontSize',fontXY)
ylabel('Relative Permeability, $k_{rel}$ [-]','interpreter','latex','FontSize',fontXY)
legend('$k_{rel,l}$','$k_{rel,g}$','interpreter','latex','FontSize',fontLeg)
grid on
nexttile
plot(s_e,p_c./1e5,'LineWidth',2)
xlabel('Effective Saturation, $s_e$ [-]','interpreter','latex','FontSize',fontXY)
ylabel('Capillary Pressure, $p_c$ [bar]','interpreter','latex','FontSize',fontXY)
grid on
nexttile
hold on
plot(s_e,F_D2,'--','LineWidth',2)
plot(s_e,F_D1,'LineWidth',2)
ax = gca;
ax.FontSize = fontGCA;
xlabel('Effective Saturation [-]','interpreter','latex','FontSize',fontXY)
ylabel('$F_{Darcy,i}/\mathbf{u}_i$ [Nm/s]','interpreter','latex','FontSize',fontXY)
legend('$F_{D,l}$','$F_{D,g}$','interpreter','latex','FontSize',fontLeg)
grid on
nexttile
plot(s_e,F_D2./F_D1,'LineWidth',2)
xlabel('Effective Saturation [-]','interpreter','latex','FontSize',fontXY)
ylabel('$(F_{Darcy,l}/\mathbf{u}_l)/(F_{Darcy,g}/\mathbf{u}_g)$','interpreter','latex','FontSize',fontXY)
grid on

%%
close all;
figure('units','normalized','outerposition',[0.1 0.1 0.75 0.75])
tiledlayout(1,2)
nexttile
hold on
plot(s_e,k_rell,'--','LineWidth',2)
plot(s_e,k_relg,'LineWidth',2)
plot(0.1,k_rell(1),'rx','MarkerSize',10,'LineWidth',1.5)
plot(0.1,k_relg(1),'rx','MarkerSize',10,'LineWidth',1.5)
plot([0.1;0.1],[0;k_relg(1)],'r-.','LineWidth',1.5)
ax = gca;
ax.FontSize = fontGCA;
xlabel('Effective Saturation, $s_e$ [-]','interpreter','latex','FontSize',fontXY)
ylabel('Relative Permeability, $k_{rel}$ [-]','interpreter','latex','FontSize',fontXY)
legend('$k_{rel,l}$','$k_{rel,g}$','interpreter','latex','FontSize',fontLeg)
grid on
box on
nexttile
plot(s_e,p_c./1e5,'LineWidth',2)
hold on
plot(0.1,p_c(1)/1e5,'rx','MarkerSize',10,'LineWidth',1.5)
plot([0.1;0.1],[0;p_c(1)/1e5],'r-.','LineWidth',1.5)
box on
ax = gca;
ax.FontSize = fontGCA;
xlabel('Effective Saturation, $s_e$ [-]','interpreter','latex','FontSize',fontXY)
ylabel('Capillary Pressure, $p_c$ [bar]','interpreter','latex','FontSize',fontXY)
grid on