%% Blending
clc; close all; clear all;
%%
c1 = 0.3;
c2 = 0.5;
a = 1/(c2-c1);
b = -a*c1;
x = 0:0.01:1;
x1 = 0:0.01:c1;
x2 = c1:0.01:c2;
x3 = c2:0.01:1;
y1 = zeros(1,length(x1));
y2 = a*x2+b;
y3 = ones(1,length(x3));
y = [y1(1:end-1) y2 y3(2:end)];

plot(x,y,'LineWidth',2)
grid on
ylim([0 1.2])
box on
ylabel('Blending factor [-]','Interpreter','latex','FontSize',15)
xlabel('Volume phase fraction of oxygen, $\alpha_{O2}$ [-]','Interpreter','latex','FontSize',15)
text(0.05,0.05,'Dispersed','Interpreter','latex','FontSize',14)
text(0.45,0.62,'Mixed','Interpreter','latex','FontSize',14)
text(0.7, 1.05,'Continous','Interpreter','latex','FontSize',14)
% annotation('textbox', [0.2, 0.2, 0.1, 0.1], 'String', "Mixed",'Interpreter','latex','FontSize',15)
% annotation('textbox', [0.6, 0.2, 0.1, 0.1], 'String', "Dispersed",'Interpreter','latex','FontSize',15)
% annotation('textbox', [0.7, 0.2, 0.1, 0.1], 'String', "Continous",'Interpreter','latex','FontSize',15)