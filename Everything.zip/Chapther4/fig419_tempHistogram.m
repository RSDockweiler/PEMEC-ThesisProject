%% T Histograms

%% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 2);

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["bin_extents", "bin_values"];
opts.VariableTypes = ["double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Import the data
%To2 = readtable("C:\Users\Dockweiler\OneDrive - Aalborg Universitet\p10\MATLAB\To2.csv", opts);
%Twater = readtable("C:\Users\Dockweiler\OneDrive - Aalborg Universitet\p10\MATLAB\Twater.csv", opts);
To2 = readtable("To2-Porous.csv", opts);
Twater = readtable("Twater-Porous.csv", opts);

%% Convert to output type
To2 = table2array(To2);
Twater = table2array(Twater);

%% Clear temporary variables
clear opts

%% Plots
meanTwater = sum(Twater(:,1).*Twater(:,2))./sum(Twater(:,2));
meanTo2 = sum(To2(:,1).*To2(:,2))./sum(To2(:,2));
close all;
plot(To2(:,1),To2(:,2)./sum(To2(:,2)),'LineWidth',1.5)
hold on
plot(Twater(:,1),Twater(:,2)./sum(Twater(:,2)),'--','LineWidth',1.5)
plot(meanTo2,0.006704,'x','MarkerSize',12,'LineWidth',2)
%plot(meanTwater,0.006737,'x','MarkerSize',12,'LineWidth',2)
grid on
legend('$\langle T_{O2}\rangle$','$\langle T_{H2O}\rangle$', ...
    '$\langle\overline{T}\rangle$','interpreter','latex','FontSize',13)
xlabel('Temperature, $T$ [K]','Interpreter','latex','FontSize',14)
ylabel('Probability [-]','Interpreter','latex','FontSize',14)

