%% Phase Change Estimate
clear all; clc;
%% Inputs
l = 50e-3; % Length of channel
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer

A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2
perimeter = 2*h_ch+2*w_ch; % perimeter, for hyd diameter
A_c = w_ch*h_ch; % cross sectional area, inlet/outlet
D_h = 4*A_c/perimeter; % hydraulic diameter
A_c_total = w_ch*h_ch + (w_l*2+w_ch)*h_l;



M_H2O = 18e-3; % kg/mol
M_O2 = 32e-3; % kg/mol
F =  9.6485e4; % Faradays, C/mol

T = 273+80;
p = 1e5;
p_sat = 47.42e3;
rho_air = M_O2*p/(8.314*T); % Density air
rho_water_vapour = M_H2O*p/(8.314*T); % Density air
rho_water = 971.8; % Density water (EES)


lambda = 1:1:500; % Stoichometric flow ratio
j = 1:5; % A/cm^2, current density
m_dot_in = zeros(length(lambda),length(j));
m_dot_O2 = m_dot_in;
n_dot_O2 = m_dot_in;
n_dot_in = m_dot_in;
n_dot_H2O_vapor = m_dot_in;
m_dot_H2O_vapor = m_dot_in;
for i = 1:length(lambda)
    for k=1:length(j)
        m_dot_in(i,k) = M_H2O*lambda(i)*j(k)*A_mea_cm/(2*F); % Mass flow in, H2O
        m_dot_O2(i,k) = M_O2*j(k)*A_mea_cm/(4*F); % O2 generation
        n_dot_in(i,k) = lambda(i)*j(k)*A_mea_cm/(2*F); % Mass flow in, H2O
        n_dot_O2(i,k) = j(k)*A_mea_cm/(4*F); % O2 generation
        n_dot_H2O_vapor(i,k) = n_dot_O2(i,k)/(p/p_sat-1);
        m_dot_H2O_vapor(i,k) = n_dot_H2O_vapor(i,k)*M_H2O;
    end
end
m_dot_H2O_l = m_dot_in - m_dot_H2O_vapor;
n_dot_H2O_l = m_dot_H2O_l./M_H2O;


V_dot_O2 = m_dot_O2./rho_air;
V_dot_in = m_dot_in./rho_water;
V_dot_H2O_vapor = m_dot_H2O_vapor./rho_water_vapour;
V_dot_H2O = m_dot_H2O_l./rho_water;

V_dot_total = V_dot_O2 + V_dot_H2O + V_dot_H2O_vapor;
m_dot_total = m_dot_O2 + m_dot_H2O_l + m_dot_H2O_vapor;

vRatioO2 = V_dot_O2 ./ V_dot_total;
vRatioIn = V_dot_H2O ./ V_dot_total;
vRatioH2O = V_dot_H2O_vapor ./ V_dot_total;
vRatio_inOut = V_dot_H2O./V_dot_in;

mRatioO2 = m_dot_O2 ./ m_dot_total;
mRatioIn = m_dot_H2O_l ./ m_dot_total;
mRatioH2O = m_dot_H2O_vapor ./ m_dot_total;
mRatio_inOut = m_dot_H2O_l./m_dot_in;

%% Heat Transfer
hWater0 = py.CoolProp.CoolProp.PropsSI('H','T',T,'Q',0,'Water');
hWater1 = py.CoolProp.CoolProp.PropsSI('H','T',T,'Q',1,'Water');
Deltah_evap = hWater1 - hWater0; 
Qdot = Deltah_evap*m_dot_H2O_vapor;
q = Qdot/A_mea_cm;
%% Plots
AXFont = 11;
YFont = 14;
XFont = 14;
TitFont = 12;
LegFont = 13;

close all;
tiledlayout(1,2)
nexttile
hold on
for i = 1:length(1)
    plot(lambda,vRatioO2(:,i),'-')
    plot(lambda,vRatioIn(:,i),'--')
    plot(lambda,vRatioH2O(:,i),'-.')
    plot(lambda,vRatio_inOut(:,i),':','LineWidth',1.5)
end
plot(lambda(350),vRatioO2(350,i),'o','MarkerSize',8,'MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
plot(lambda(350),vRatioIn(350,i),'x','MarkerSize',10,'LineWidth',3,'MarkerEdgeColor',[0.8500 0.3250 0.0980],'MarkerFaceColor',[0.8500 0.3250 0.0980])
plot(lambda(350),vRatioH2O(350,i),'s','MarkerSize',8,'LineWidth',2,'MarkerEdgeColor',[0.9290 0.6940 0.1250],'MarkerFaceColor',[0.9290 0.6940 0.1250])
plot(lambda(350),vRatio_inOut(350,i),'*','MarkerSize',8,'LineWidth',2,'MarkerEdgeColor',[0.4940 0.1840 0.5560],'MarkerFaceColor',[0.4940 0.1840 0.5560])
legend('$\dot{V}_{O2}/\dot{V}_{tot}$','$\dot{V}_{H2O,l}/\dot{V}_{tot}$' ...
     ,'$\dot{V}_{H2O,g}/\dot{V}_{tot}$','$\dot{V}_{H2O,g,out}/\dot{V}_{H2O,l,in}$','FontSize',LegFont,'interpreter','latex')
xlim([0 500])
grid on
ax = gca; % current axes
ax.FontSize = AXFont;
xlabel('Stoichiometric flow ratio, $\lambda$ [-]','FontSize',XFont,'interpreter','latex')
ylabel('Volume Flow Ratio, $\dot{V}_i/\dot{V}_j$ [-]','FontSize',YFont,'interpreter','latex')
box on

% nexttile
% hold on
% for i = 1:length(1)
%     plot(lambda,mRatioO2(:,i),'-')
%     plot(lambda,mRatioIn(:,i),'--')
%     plot(lambda,mRatioH2O(:,i),'-.')
%     plot(lambda,mRatio_inOut(:,i),':','LineWidth',1.5)
% end
% plot(lambda(350),mRatioO2(350,i),'o','MarkerSize',8,'MarkerEdgeColor',[0 0.4470 0.7410],'MarkerFaceColor',[0 0.4470 0.7410])
% plot(lambda(350),mRatioIn(350,i),'x','MarkerSize',10,'LineWidth',3,'MarkerEdgeColor',[0.8500 0.3250 0.0980],'MarkerFaceColor',[0.8500 0.3250 0.0980])
% plot(lambda(350),mRatioH2O(350,i),'s','MarkerSize',8,'LineWidth',2,'MarkerEdgeColor',[0.9290 0.6940 0.1250],'MarkerFaceColor',[0.9290 0.6940 0.1250])
% plot(lambda(350),mRatio_inOut(350,i),'*','MarkerSize',8,'LineWidth',2,'MarkerEdgeColor',[0.4940 0.1840 0.5560],'MarkerFaceColor',[0.4940 0.1840 0.5560])
% legend('$\dot{m}_{O2}/\dot{m}_{tot}$','$\dot{m}_{H2O,l}/\dot{m}_{tot}$' ...
%      ,'$\dot{m}_{H2O,g}/\dot{m}_{tot}$','$\dot{m}_{H2O,g,out}/\dot{m}_{H2O,l,in}$','interpreter','latex','FontSize',LegFont)
% xlim([0 500])
% grid on
% ax = gca; % current axes
% ax.FontSize = AXFont;
% xlabel('Stoichiometric flow ratio, $\lambda$ [-]','FontSize',XFont,'interpreter','latex')
% ylabel('Mass Flow Ratio, $\dot{m}_i/\dot{m}_j$ [-]','FontSize',YFont,'interpreter','latex')
% box on

heatTransferEvap % script calculating q_evap/q
AXFont = 11;
YFont = 14;
XFont = 14;
TitFont = 12;
LegFont = 13;

nexttile
plot(i,q_evap./q)
xlim([0.2 1.2])
ylim([0 1])
grid on
ax = gca; % current axes
ax.FontSize = AXFont;
ylabel('Heat flux ratio, $q_{reaction}/q_{evap}$ [-]','FontSize',YFont,'Interpreter','latex')
xlabel('Current Density, $i$ [A/cm$^2$]','FontSize',XFont,'Interpreter','latex')
