%% FLow MAP
clear all; close all; clc;
%% Inputs
l = 50e-3; % Length of channel
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer

A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2
perimeter = 2*h_ch+2*w_ch; % perimeter, for hyd diameter
A_c = w_ch*h_ch; % cross sectional area, inlet/outlet
D_h = 4*A_c/perimeter; % hydraulic diameter
A_c_total = w_ch*h_ch + (w_l*2+w_ch)*h_l;



M_H2O = 18e-3; % kg/mol
M_O2 = 32e-3; % kg/mol
F =  9.6485e4; % Faradays, C/mol

T = 273+80;
p = 101325;

rho_water_ref = py.CoolProp.CoolProp.PropsSI('D','T',20+273,'P',101325,'Water');
rho_o2_ref = py.CoolProp.CoolProp.PropsSI('D','T',20+273,'P',p,'Oxygen');
rho_water = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Water');
rho_o2 = py.CoolProp.CoolProp.PropsSI('D','T',T,'P',p,'Oxygen');
mu_water_ref = py.CoolProp.CoolProp.PropsSI('V','T',20+273,'P',101325,'Water');
mu_water = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Water');
mu_o2 = py.CoolProp.CoolProp.PropsSI('V','T',T,'P',p,'Oxygen');
sigma_water_ref = py.CoolProp.CoolProp.PropsSI('I','T',20+273,'Q',0,'Water');
sigma_water = py.CoolProp.CoolProp.PropsSI('I','T',T,'Q',0,'Water');

lambda_baker = ((rho_o2/rho_o2_ref)*(rho_water/rho_water_ref))^(1/2); % baker parameter
psi_baker = sigma_water_ref/sigma_water * ((mu_water/mu_water_ref)*(rho_water_ref/rho_water)^2)^(1/3);


%% Calculations
lambda = 100:125:350; % Stoichometric flow ratio
j = 1:5; % A/cm^2, current density
u_l_out = zeros(length(lambda),length(j));
u_g_out = u_l_out;
u_l_ch = u_l_out;
u_g_ch = u_l_out;
G_l_out = zeros(length(lambda),length(j));
G_g_out = u_l_out;

for i = 1:length(lambda)
    for k=1:length(j)
        m_dot_in = M_H2O*lambda(i)*j(k)*A_mea_cm/(2*F); % Mass flow in, H2O
        m_dot_O2 = M_O2*j(k)*A_mea_cm/(4*F); % O2 generation
        % Superficial velocities
        u_l_out(i,k) = m_dot_in/(A_c*rho_water);
        u_g_out(i,k) = m_dot_O2/(A_c*rho_o2);
        G_g_out(i,k) = m_dot_O2/A_c;
        G_l_out(i,k) = m_dot_in/A_c;
    end
end

u_g_bubbly = 10^1;
u_l_bubbly = 10^1;
u_g_plug = 1*10^(-1);
u_l_plug = 5*10^(-1);

u_g_slug = 5*10^(0);
u_l_slug = 5*10^(-1);
u_g_annular = 0.6*10^(2);
u_l_annular = 2*10^(0);

i_bubbly = u_g_bubbly*A_c*rho_o2*4*F/(M_O2*A_mea_cm);
lambda_bubbly = u_l_bubbly*A_c*rho_water*4*F/(i_bubbly*M_O2*A_mea_cm);

i_plug = u_g_plug*A_c*rho_o2*4*F/(M_O2*A_mea_cm);
lambda_plug = u_l_plug*A_c*rho_water*4*F/(i_plug*M_O2*A_mea_cm);

i_slug = u_g_slug*A_c*rho_o2*4*F/(M_O2*A_mea_cm);
lambda_slug = u_l_slug*A_c*rho_water*4*F/(i_slug*M_O2*A_mea_cm);

i_annular = u_g_annular*A_c*rho_o2*4*F/(M_O2*A_mea_cm);
lambda_annular = u_l_annular*A_c*rho_water*4*F/(i_annular*M_O2*A_mea_cm);

%% Figures
close all;
legFont = 16;
mar = ['-o';'-s';'-*';'-x';'-+'];
figure(1) % Mandhane
for i = 1:length(j)
    loglog(u_l_out(:,i),u_g_out(:,i),mar(i,:),'MarkerSize',10)
    hold on
end
ylim([5*10^(-2) 5*10^2])
xlim([5*10^(-3) 4*10^1])
grid on
legend('j = 1 [A/cm$^2$]','j = 2 [A/cm$^2$]','j = 3 [A/cm$^2$]', ...
    'j = 4 [A/cm$^2$]','j = 5 [A/cm$^2$]','interpreter','latex','FontSize',legFont)
