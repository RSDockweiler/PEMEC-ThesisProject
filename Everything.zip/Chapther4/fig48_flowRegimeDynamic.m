%% Fluctuations for flow regimes
clear all; close all; clc;
%% Set up the Import Options and import the data
opts = delimitedTextImportOptions("NumVariables", 6);

% Specify range and delimiter
opts.DataLines = [2, Inf];
opts.Delimiter = ",";

% Specify column names and types
opts.VariableNames = ["Time", "avgalphao2", "maxalphao2", "minalphao2", "q1alphao2", "q3alphao2"];
opts.VariableTypes = ["double", "double", "double", "double", "double", "double"];

% Specify file level properties
opts.ExtraColumnsRule = "ignore";
opts.EmptyLineRule = "read";

% Import the data
plugQuartileTest = readtable("plugQuartileTest.csv", opts);
slugQuartileTest = readtable("slugQuartileTest.csv", opts);
stratQuartileTest = readtable("stratQuartileTest.csv", opts);

%% Convert to output type
plug = table2array(plugQuartileTest);
slug = table2array(slugQuartileTest);
strat = table2array(stratQuartileTest);

%% Clear temporary variables
clearvars -except plug slug strat;

%% Calculations

slugMin = (3.1-min(slug(:,1)))/(max(slug(:,1))-min(slug(:,1)));
slugMid = (3.5-min(slug(:,1)))/(max(slug(:,1))-min(slug(:,1)));
slugMax = (3.2-min(slug(:,1)))/(max(slug(:,1))-min(slug(:,1)));

plugMin = (7.2-min(plug(:,1)))/(max(plug(:,1))-min(plug(:,1)));
plugMid = (7.35-min(plug(:,1)))/(max(plug(:,1))-min(plug(:,1)));
plugMax = (7.75-min(plug(:,1)))/(max(plug(:,1))-min(plug(:,1)));

stratMin = (10.3-min(strat(:,1)))/(max(strat(:,1))-min(strat(:,1)));
stratMid = (9.4-min(strat(:,1)))/(max(strat(:,1))-min(strat(:,1)));
stratMax = (8.2-min(strat(:,1)))/(max(strat(:,1))-min(strat(:,1)));

plug(:,1) = linspace(0,1,length(plug(:,1)));
slug(:,1) = linspace(0,1,length(slug(:,1)));
strat(:,1) = linspace(0,1,length(strat(:,1)));



%%
close all;
tiledlayout(3,1)
nexttile
hold on
plot(strat(:,1),strat(:,2),'LineWidth',2)
plot(strat(:,1),strat(:,3),'--','Color',[0.6350 0.0780 0.1840])
plot(strat(:,1),strat(:,4),'--','Color',[0.6350 0.0780 0.1840])
plot(strat(:,1),strat(:,5),'-.','Color',[0.9290 0.6940 0.1250])
plot(strat(:,1),strat(:,6),'-.','Color',[0.9290 0.6940 0.1250])
plot([stratMin stratMin],[0 1],'r','LineWidth',1)
plot([stratMid stratMid],[0 1],'r','LineWidth',1)
plot([stratMax stratMax],[0 1],'r','LineWidth',1)
grid on
%ylabel('Oxygen volume phase fraction, $\alpha_{O2}$ [-]','Interpreter','latex')
%xlabel('Normalised time, $(t-t_{start})/(t_{end}-t_{start})$','Interpreter','latex')
nexttile
hold on
plot(plug(:,1),plug(:,2),'LineWidth',2)
plot(plug(:,1),plug(:,3),'--','Color',[0.6350 0.0780 0.1840])
plot(plug(:,1),plug(:,4),'--','Color',[0.6350 0.0780 0.1840])
plot(plug(:,1),plug(:,5),'-.','Color',[0.9290 0.6940 0.1250])
plot(plug(:,1),plug(:,6),'-.','Color',[0.9290 0.6940 0.1250])
plot([plugMin plugMin],[0 1],'r','LineWidth',1)
plot([plugMid plugMid],[0 1],'r','LineWidth',1)
plot([plugMax plugMax],[0 1],'r','LineWidth',1)
grid on
ylim([0 0.15])
ylabel('Oxygen volume phase fraction, $\alpha_{O2}$ [-]','Interpreter','latex','FontSize',14)
%xlabel('Normalised time, $(t-t_{start})/(t_{end}-t_{start})$','Interpreter','latex')
nexttile
hold on
plot(slug(:,1),slug(:,2),'LineWidth',2)
plot(slug(:,1),slug(:,3),'--','Color',[0.6350 0.0780 0.1840])
plot(slug(:,1),slug(:,4),'--','Color',[0.6350 0.0780 0.1840])
plot(slug(:,1),slug(:,5),'-.','Color',[0.9290 0.6940 0.1250])
plot(slug(:,1),slug(:,6),'-.','Color',[0.9290 0.6940 0.1250])
plot([slugMin slugMin],[0 1],'r','LineWidth',1)
plot([slugMid slugMid],[0 1],'r','LineWidth',1)
plot([slugMax slugMax],[0 1],'r','LineWidth',1)

grid on
%ylabel('Oxygen volume phase fraction, $\alpha_{O2}$ [-]','Interpreter','latex')
xlabel('Normalised time, $(t-t_{start})/(t_{end}-t_{start})$ [-]','Interpreter','latex','FontSize',14)