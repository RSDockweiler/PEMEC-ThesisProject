%% Heat Transfer
polCurve % running polCurve to get V and i
clc; clearvars -except V i;
%% Properties
T = 273+20;
p = 1e5;

hWater0 = py.CoolProp.CoolProp.PropsSI('H','T',T,'Q',0,'Water');
hWater1 = py.CoolProp.CoolProp.PropsSI('H','T',T,'Q',1,'Water');
% Molar mass, kg/mol
M_H2 = 2e-3;
M_O2 = 32e-3;
M_H2O = 18e-3;
%Deltah = 0.5*hOxygen*M_O2-hWater*M_H2O
Deltah = 285.8e3; % Liquid water
Deltah_evap = hWater1 - hWater0; 
n = 4;
F = 9.648533212*10^4; % Faraday
%% Heat Flux
q = (V'-Deltah/(2*F)).*i;

%% Phase change calculations
l = 50e-3; % Length of channel
h_ch =1e-3; % Channel height
w_ch =1e-3; % Channel width
w_l = 1e-3; % Land width (uniform, both sides)
h_l = 1e-3; % Height porous layer

A_mea = (w_l*2+w_ch)*l; % Active membrane area
A_mea_cm = A_mea*10^(4); % Active membrane area in cm^2


p_sat = 47.42e3;
rho_air = M_O2*p/(8.314*T); % Density air
rho_water_vapour = M_H2O*p/(8.314*T); % Density air



m_dot_O2 = zeros(length(j),1);
n_dot_O2 = zeros(length(j),1);
n_dot_H2O_vapor = zeros(length(j),1);
m_dot_H2O_vapor = zeros(length(j),1);

for j = 1:length(i)
        m_dot_O2(j) = M_O2*i(j)*A_mea_cm/(4*F); % O2 generation
        n_dot_O2(j) = i(j)*A_mea_cm/(4*F); % O2 generation
        n_dot_H2O_vapor(j) = n_dot_O2(j)/(p/p_sat-1);
        m_dot_H2O_vapor(j) = n_dot_H2O_vapor(j)*M_H2O;
end
q_evap = m_dot_H2O_vapor*Deltah_evap/A_mea_cm;

